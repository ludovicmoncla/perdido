

class Geocoder:
    def __init__(self):
        pass

