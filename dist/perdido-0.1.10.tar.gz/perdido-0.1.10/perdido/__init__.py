from perdido.utils.webservices import WebService
from perdido.utils.xml import *
from perdido.utils.map import *