

class Geocoder:
    def __init__(self) -> None:
        pass

